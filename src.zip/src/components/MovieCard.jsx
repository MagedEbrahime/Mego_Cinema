import React from 'react'
import { Link} from 'react-router-dom'
function MovieCard() {
  return (
    <div className="col-md-3 col-sm-6">
  <div className="card p-3 text-center">
    <img src={require("../images/movie.jpg")}  className="w-75 mx-auto" alt="" />
    <h4> اسم الفيلم</h4>
    <h4> سنة الانتاج</h4>
    <h4>التتقيم 0.9</h4>
    <Link to="/details/1" className="btn btn-danger"> تفاصيل</Link>
  </div>{/* card */}
</div>

  )
}

export default MovieCard