import React from 'react'
import MovieCard from './MovieCard'
function MoviesList() {
  return (
<section id="movies-list" className="py-5">
  <div className="container">
    <div className="row">

      <MovieCard/>
      
    </div> {/* row */}
  </div>{/* container */}
</section>

  )
}

export default MoviesList