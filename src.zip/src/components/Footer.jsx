import React from 'react'
import { FaCopyright } from 'react-icons/fa';
function Footer() {
  return (
    <footer class="py-4 bg-black text-white text-center" >
    <h4>امينة موفيز</h4>
    <p>تم البرمجة والتصميم بواسطة مهندسة أمينة سمير  <FaCopyright/> 2023</p>
</footer>
  )
}

export default Footer