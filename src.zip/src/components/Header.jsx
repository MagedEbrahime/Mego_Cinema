import React from 'react'
import logo from '../images/Logo.png'
import { FaSearch } from 'react-icons/fa';
import { Link} from 'react-router-dom'
function Header() {
  return (
   <header className="py-4 bg-black"> 
  <div className="container">
    <div className="row">
      <div className="col-2 text-center">
        <Link to="/">
        <img src={logo} className="w-75 mt-2" alt="" />
        </Link>
      </div>{/* col-2 */}
      <div className="col-10">
        <div className="input-group">
          <span className="input-group-text"> <FaSearch size={30}  /> </span>
          <input type="text" className="form-control form-control-lg" placeholder="ابحث هنا عن الافلام والمسلسلات" />
        </div>
      </div> {/* col-10 */}
    </div> {/* row */}
  </div>{/* container */}
</header>

  )
}

export default Header