import React from 'react'
import Header from './components/Header'
import MoviesList from './components/MoviesList'
import Footer from './components/Footer'
import Details from './components/Details'
import { Route, Routes } from 'react-router-dom'

function App() {
  return (
    <div>
      <Header/>

      <Routes>
        <Route path='/' element={<MoviesList/>} />
        <Route path='/details/:id' element={<Details/>} />
      </Routes>
    
      <Footer/>
    </div>
  )
}

export default App